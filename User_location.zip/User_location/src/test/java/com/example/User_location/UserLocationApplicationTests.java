package com.example.User_location;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
