package com.example.appsecurity2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppSecurity2Application {

	public static void main(String[] args) {
		SpringApplication.run(AppSecurity2Application.class, args);
	}

}
